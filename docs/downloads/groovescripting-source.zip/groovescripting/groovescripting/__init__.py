"""GrooveScripting: shared offline music engine and command tools."""

__version__ = "0.5.0"

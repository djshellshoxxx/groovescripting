# GrooveScripting

Offline command line drum, bass and lead synthesis with sequencing, deterministic variation, automation, MIDI interchange, mixing, effects, playback and WAV inspection. Built for reproducible loops and shell based arrangements.

## Install

Requires Python 3.10+. Follow the [Linux and Windows installation guide](docs/installation.md) for prerequisites, isolated environments, playback, troubleshooting and uninstall commands.

Linux / macOS, from the source directory:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install ".[playback]"
```

Windows PowerShell, from the source directory (activation is optional):

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install ".[playback]"
.\.venv\Scripts\groovseq.exe --help
```

Install `.` instead of `.[playback]` for offline rendering alone.

## First groove

```sh
groovseq examples/first-groove.json --output groove.wav --stems stems
groovplay groove.wav
groovinfo groove.wav --json
```

Use `examples/arrangement.json` for a section based arrangement. Protect existing outputs by default; add `--overwrite` deliberately when replacing them.

| Command | Purpose |
| --- | --- |
| `groovdrm` | Procedural seven voice drums |
| `groovbss` | Bass synthesis |
| `groovld` | Lead synthesis |
| `groovmix` | WAV track mixing |
| `groovseq` | JSON project arrangement and stems |
| `groovfx` | Ordered audio effects |
| `groovplay` | Playback, device listing and diagnostics |
| `groovinfo` | WAV metadata and signal statistics |
| `groovmidi` | MIDI project import/export |
| `groovlint` | Project, preset and audio checks with stable rule IDs |
| `groovdebug` | Step through an arrangement's events and ask why each one played |
| `groovtest` | Musical assertions over a project's event trace |
| `groovtime` | Inspect, render and diff earlier Git revisions of a project |
| `groovmerge` | Semantic three-way merge of project files |

Use `--variation` and `--density` on synth commands for seeded pattern mutation; drums also support `--ghost-notes` and `--fill-every`. Project tracks support gain, pan, cutoff and saturation automation lanes. `groovmidi import` converts melodic MIDI into a project and `groovmidi export` writes project arrangements as Standard MIDI Files.

```sh
groovdrm --preset breakbeat --bars 4 --variation 0.3 --ghost-notes 0.08 --fill-every 4 -o varied-break.wav
groovmidi import phrase.mid --output phrase.json --instrument lead
groovmidi export examples/arrangement.json --output arrangement.mid
```

## Musical developer tools

```sh
groovlint examples/arrangement.json --audio groove.wav --strict
groovdebug examples/arrangement.json --break 2 --where 'track == "Bass" and velocity < 0.8'
groovdebug examples/arrangement.json --format json --trace-out arrangement.trace.jsonl
groovtest my-suite.json
groovtime log song.json && groovtime diff song.json --from HEAD~1 --to WORKTREE
groovmerge base.json mine.json theirs.json --output merged.json --take track:Bass=theirs
```

Every event in a trace records its source JSON Pointer, section and repeat, and each decision applied to it (probability roll, swing, humanize, velocity humanize, variation, scale/arpeggio resolution and voice limits). Tracing never changes audio. Specs: `spec/groovlint.md`, `spec/groovdebug.md`, `spec/groovtest.md`, `spec/groovtime.md`, `spec/groovmerge.md`, `spec/provenance.md`.

## Standalone executables

Each GitHub Release includes `groovescripting-windows-x64.exe` and `groovescripting-linux-x64` built with PyInstaller; no Python installation is needed. Run any tool as the first argument, for example `groovescripting-windows-x64.exe groovseq project.json --output song.wav`. Copy or rename the file to a tool name (for example `groovseq.exe`) to run that tool directly. On Linux, `chmod +x groovescripting-linux-x64` first; playback needs `libportaudio2`.

Automation lanes live on a project track and use absolute arrangement beats:

```json
"automation": [
  {
    "param": "cutoff",
    "curve": "linear",
    "points": [
      {"beat": 0, "value": 300},
      {"beat": 16, "value": 6000}
    ]
  }
]
```

Each command exposes `--help`. Website source and detailed command documentation are in `docs/`; engineering specifications are in `spec/`. Every command has CLI help; `docs/reference.html` contains the generated full flag defaults and ranges.

## Live ASCII waveform

Add `--visualizer` to any playback to draw a scrolling ASCII waveform in the terminal that follows the music. It is off by default; `--no-visualizer` turns it off explicitly, which is handy for overriding a wrapper script.

```sh
groovplay groove.wav --visualizer
groovseq examples/first-groove.json --play-only --visualizer --visualizer-height 13
```

```text
    #                               |                                   
    ###             ##             #|             ###             ####  
################### ################|############################ ######
####################################|###################################
    ####### ## #    ###    ##      #|### # ##      ###    #       #### #
00:01.3 / 00:03.4  [================================      ]   -1.4 dB
```

The `|` column is the playhead, centred in a two second window; the last row shows elapsed time, total length and the current peak level. The display is plain ASCII on stderr, so it works over SSH (PuTTY included) and keeps `--json` output on stdout clean. It is skipped with a logged warning when stderr is not an interactive terminal. Rendering commands accept it only with `--play` or `--play-only`.

## Troubleshooting logs

```sh
groovseq examples/first-groove.json --output debug.wav --log-file render.log --log-level debug --log-format text
groovplay --diagnose --log-file playback.jsonl --log-level debug --log-format json
```

Logs are opt in. Include the command, project, log, OS and Python version in bug reports. Fix the seed and sample rate for reproducible comparisons. Run `groovplay --devices` for playback target discovery. System volume and device access depend on OS support and local audio policy; hardware behavior requires local verification.

## More groove formulas

The [groove cookbook](examples/GROOVE_COOKBOOK.md) includes ten complete projects: house, techno, drum and bass, half time, hip hop, UK garage, hard trance, electro, dub and 7/8. Each recipe shows its drum and note patterns, tempo, swing and render commands. Editable JSON files are in `examples/grooves/`; the same recipes appear on the Pages site.

## Circuit Drift Labs

[Visit Circuit Drift Labs](https://djshellshoxxx.github.io/circuitdriftlabs/).

Run the offline recipes with `python examples/smoke.py --output-dir example-output`. Playback needs a local audio device. Linux playback may require `libportaudio2`; SoundFile source installs may require `libsndfile1`. Windows and macOS wheels generally bundle the required libraries.

## Platform installation and uninstall

On Windows use `py -m pip install .` from the source checkout; on Linux and macOS use `python3 -m pip install .` in a virtual environment. Install `.[playback]` for device access and `.[windows-volume]` only if Windows master-volume control is needed. Linux uses existing `pactl` or `amixer`; macOS uses `osascript`. Offline use needs no elevated privileges. Remove the package with `python -m pip uninstall groovescripting`. The portable fallback is `python -m groovescripting groovseq examples/first-groove.json --output groove.wav`.

## Development

```sh
python -m pip install '.[dev]'
python -m pytest
python -m build
python scripts/package_downloads.py
```

CI tests Python on Linux, Windows and macOS. The Pages workflow packages downloads then publishes `docs/`. Offline render validation and hardware validation are documented separately in `docs/verification.md`.

MIT licensed. See `LICENSE`.
